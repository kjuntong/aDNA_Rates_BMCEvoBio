library(phangorn)

trees <- grep('.nex', dir(), value = T)

for(i in 1:length(trees)){
	tr <- read.nexus(trees[i])
	tipagesplit <- strsplit(tr$tip.label, "_")
    tr$tip.label <- sapply(tipagesplit, function(x) paste0(x[[1]], "_", (as.numeric(x[[2]])*-1e5) + 500000))
	write.tree(tr, file = gsub('nex', 'tre', trees[i]))
	}

trees2 <- grep('.tre', dir(), value = T)

for(a in 1:length(trees2)){
		
	tr <- read.tree(trees2[a])
	tree_text <- readLines(trees2[a])
	tree_text_mod <- gsub('5e\\+05', '50000', tree_text)
	write(tree_text_mod, file = trees2[a])
	filename <- gsub('.tre', '_ages.txt', trees2[a])
	tipagesplit <- strsplit(tr$tip.label, '_')
	lapply(tipagesplit, write, file = filename, append = T, ncolumns = 2)
	
	age_info <- readLines(filename)
	age_info <- gsub('5e\\+05', '50000', age_info)
	for(b in 1:length(age_info)){
		sub_in <- paste0(strsplit(age_info[b], ' ')[[1]][1], '_', strsplit(age_info[b], ' ')[[1]][2])
		age_info[b] <- gsub(strsplit(age_info[b], ' ')[[1]][1], sub_in, age_info[b])
	}
	age_info[1] <- gsub('t', paste0(length(age_info), '\nt'), age_info[1])	
	write(age_info, file = filename)

}

